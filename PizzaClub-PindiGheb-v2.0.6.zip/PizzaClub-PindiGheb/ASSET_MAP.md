# Food photo map — every file must exist under assets/food/

- assets/food/pizza/pizza_chicken_tikka.jpg — Chicken Tikka, Special Cheese, Creamy Chicken Tikka, Malai Boti
- assets/food/pizza/pizza_fajita.jpg — Chicken Fajita
- assets/food/pizza/pizza_supreme.jpg — Super Supreme, Vegetarian, Pepperoni
- assets/food/pizza/pizza_tandoori.jpg — Tandoori, Hot & Spicy
- assets/food/special_pizza/pizza_special.jpg — Crown Crust, Kababish, Four Season, Pizza Club Special, Lava, Afghani
- assets/food/burgers/burger_zinger.jpg — Zinger, Tower, Double Zinger
- assets/food/burgers/burger_crispy.jpg — Crispy, Pizza Burger, Crunch, Double Crunch
- assets/food/burgers/burger_beef.jpg — Beef Burger
- assets/food/shawarma/shawarma_chicken.jpg — all Shawarma items
- assets/food/paratha/paratha_chicken.jpg — all Paratha Rolls
- assets/food/crispy_chicken/nuggets.jpg — Nuggets (6/9), Crispy Chicken Strips
- assets/food/pasta/pasta_alfredo.jpg — Crunch Pasta, Alfredo Pasta
- assets/food/pasta/pasta_tandoori.jpg — Pizza Pasta, Tandoori Special Pasta
- assets/food/wings/wings_hot.jpg — Hot Wings, Crispy Wings, Crispy Chicken Wings
- assets/food/drinks/drinks_cold.jpg — all Drinks
- assets/food/fries/fries.jpg — all Fries
- assets/food/sides/sides.jpg — Garlic Bread, Coleslaw, Salad
- assets/food/deals/deal_family.jpg — Family Deal, Pizza + Wings Deal
- assets/food/deals/deal_burger.jpg — Burger Combo, Shawarma Deal

Branding (real, supplied by Tayyab 2026-11-17):
- assets/branding/pizza_club_logo.png (526x526, from image-51.png)
- assets/branding/pizza_club_banner.png (1600px optimised hero, from image-52.png)
- assets/branding/original/pizza_club_banner_original.png (3091x1356 original)
