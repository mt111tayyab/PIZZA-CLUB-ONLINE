# Pizza Club — coordinator-owned contract (do NOT change these APIs)

Package: `pizza_club`. Money: integer paisa everywhere (`formatPkr(paisa)` in `lib/core/money.dart`, `paisaFromRs(rs)`).
Colours: `AppColors` in `lib/core/theme.dart` — yellow 0xFFFFC107, black 0xFF111111, red 0xFFD32F2F.
IDs: `newId()` / `nowIso()` in `lib/core/ids.dart`. Passwords: `PasswordHash.hash/verify` in `lib/core/password_hash.dart`.

## Data layer — use ONLY these (never call sqflite directly from a screen)
- `LocalDatabase.open()` / `LocalDatabase.path()` / `close()` — `lib/data/local_db.dart`
- `Repos` — `lib/data/repositories.dart`, constructed as `Repos(db)`. One instance is provided app-wide by `AppState` (see below).
  - Auth: `login(email, password) -> AppUser?`, `listUsers()`, `createUser(name,email,password,role)`, `setUserActive(id, active)`, `changePassword(id, newPassword)`
  - Catalog: `categories()`, `products({String? categoryId, String? search})`, `product(id)`, `sizes(productId)`, `addons(productId)`, `upsertCategory(Category)`, `deleteCategory(id)`, `upsertProduct(Product, sizes, addons)`, `setProductAvailable(id, available)`, `deleteProduct(id)`
  - Orders: `createOrder(OrderDraft draft) -> Order` (transaction: inserts order+items, deducts product stock, updates/creates customer, writes audit), `orders({String? status, String? search})`, `orderById(id)`, `orderItems(orderId)`, `updateOrderStatus(id, status)`, `ordersByCustomer(customerId)`
  - Customers: `customers({String? search})`, `customer(id)`, `findCustomerByPhone(phone)`, `upsertCustomer(Customer)`, `customerStats(id) -> {orders, spentPaisa}`
  - Inventory: `inventoryItems()`, `adjustInventory(id, delta, reason, by)`, `addInventoryItem(InventoryItem)`, `updateInventoryItem(InventoryItem)`, `recordPurchase(itemId, qty, costPaisa, by)`
  - Expenses: `expenses({DateTime? from, DateTime? to})`, `addExpense(Expense)`, `deleteExpense(id)`
  - Deals: `deals()`, `upsertDeal(Deal)`, `deleteDeal(id)`, `setDealActive(id, active)`
  - Reports: `salesSummary(from,to) -> SalesSummary`, `bestSellers(from,to,limit)`, `categorySales(from,to)`, `orderStatusCounts(from,to)`. Expense summary is computed in the screen by grouping `expenses(from,to)` by category. (There is NO `dailySales` or `expenseSummary` method.)
  - Settings: `getSetting(key, defaultValue)`, `setSetting(key, value)`, `allSettings()`
  - Backup (`lib/data/backup_service.dart`, file_picker 13.x static API): `BackupService.exportDbFile()`, `BackupService.exportJson(repos)`, `BackupService.restoreDbFile() -> Future<String?>` (null = ok, string = error), `BackupService.salesCsv(rows) -> String` (takes order row maps). (There is NO `exportToFile`/`importFromFile`.)
  - Inventory: `addInventoryItem` upserts (there is NO separate `updateInventoryItem`).
  - `Deal.discountValue` is in PAISA for fixed discounts (percent = 0-100). Seed fixed deals are stored as paisa (Rs 100 = 10000).
- `AppState` (`lib/app_state.dart`, ChangeNotifier, provided at root): holds `repos`, `currentUser`, `cart` (List<CartItem>), `cartSubtotalPaisa`, `cartCount`, `addToCart/removeFromCart/clearCart/setQty`, `loadCatalog()`, `setUser()`, role helpers `isKitchen/isDelivery/isCashier/isManagerOrAdmin`. (There is NO `cartTotalPaisa`, `refreshCatalog()` or `isWide` — use `loadCatalog()` and `MediaQuery`.) Screens read/write cart ONLY via AppState. Do not create a second cart. NOTE: POS keeps its own local `List<CartItem>` in its State so it never clashes with the customer cart.
- Receipt: `ReceiptService.buildReceiptPdf(order, items, cashierName) -> Future<Uint8List>` and `printOrShareReceipt(...)` in `lib/data/receipt_service.dart` (80mm PDF, logo, phones, thank-you). Never fake a print success — catch errors and show them.

## Models — `lib/data/models.dart`
Category{id,name,sortOrder}; Product{id,categoryId,name,description,pricePaisa,imageAsset,isAvailable,sortOrder,hasSizes};
ProductSize{id,productId,name,pricePaisa}; Addon{id,productId,name,pricePaisa};
CartItem{product, size (ProductSize?), addons, qty, instructions} with `unitPricePaisa` and `totalPaisa` getters;
Order{id,orderNumber,customerId,customerName,customerPhone,address,instructions,type,status,subtotalPaisa,discountPaisa,deliveryFeePaisa,totalPaisa,paymentMethod,paymentStatus,cashierId,cashierName,createdAt};
OrderItem{id,orderId,productId,productName,sizeName,addonsJson,qty,unitPricePaisa,totalPaisa,instructions};
Customer{id,name,phone,address,notes,isActive,createdAt}; InventoryItem{id,name,unit,quantity,minQuantity,costPaisa};
Expense{id,title,category,amountPaisa,expenseDate,notes,createdBy}; Deal{id,title,description,discountType ('percent'|'fixed'), discountValue, categoryId, isActive, validUntil, imageAsset};
AppUser{id,name,email,role ('admin'|'manager'|'cashier'|'kitchen'|'delivery'),phone,isActive};
OrderStatus values: 'received','accepted','preparing','ready','out_for_delivery','completed','rejected','cancelled'.
OrderType values: 'delivery','takeaway','dine-in'. Payment: 'Cash','Cash on Delivery','Card','Other'.

## OrderDraft (for createOrder)
`OrderDraft({customerName,customerPhone,address,instructions,type,paymentMethod,discountPaisa,deliveryFeePaisa,cashierId,cashierName, items: List<CartItem>})` — totals are computed inside the repository transaction, never trusted from the UI.

## Seed data — `lib/data/seed_data.dart`
Categories + products + sizes + addons + inventory + deals + default admin `admin@pizzaclub.pk` / `Admin123!`. Prices are PLACEHOLDER PKR (see README). Every product's `imageAsset` must exist under `assets/food/...` — check `ASSET_MAP.md` before referencing a photo.

## UI rules
- Material 3, AppColors only as primary brand. No emoji as icons (Material Icons only). No lorem ipsum, no dead buttons.
- Mobile: bottom nav Home/Menu/Cart/Orders/Profile. Wide >=900px: sidebar (Dashboard, Orders, POS, Kitchen, Menu, Customers, Inventory, Expenses, Reports, Settings).
- Every screen must handle empty state + loading + error with a friendly message. Use `SingleChildScrollView` / `ListView` — never a fixed-height Column that can overflow.
- Role gating: `AppState.currentUser.role` — kitchen sees Kitchen only (+ logout), delivery sees assigned delivery orders, cashier sees POS+Orders, manager sees all except Users/Settings-admin, admin sees everything. Enforce in AppShell, not just by hiding a button.
- Files: customer screens in `lib/features/customer/`, POS in `lib/features/pos/`, kitchen in `lib/features/kitchen/`, staff orders in `lib/features/orders/`, admin in `lib/features/admin/`, auth in `lib/features/auth/`, shared widgets in `lib/widgets/`. One screen per file, named as in the task list you were given.
