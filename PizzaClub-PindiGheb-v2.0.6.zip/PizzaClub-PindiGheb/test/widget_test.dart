// Pizza Club offline tests: money, password hashing, DB seed + order flow.
// Uses an in-memory sqflite database via sqflite_common_ffi (Linux test host).
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pizza_club/app_state.dart';
import 'package:pizza_club/data/online_service.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:pizza_club/core/money.dart';
import 'package:pizza_club/core/password_hash.dart';
import 'package:pizza_club/data/local_db.dart';
import 'package:pizza_club/data/models.dart';
import 'package:pizza_club/data/repositories.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();

  test('money is integer paisa, formatted as Rs', () {
    expect(paisaFromRs(750), 75000);
    expect(formatPkr(75000), 'Rs 750');
    expect(formatPkr(110000), 'Rs 1,100');
    expect(formatPkr(0), 'Rs 0');
  });

  test('guest mode: customer in without sign-in, staff sign-in ends it', () async {
    final db = await LocalDatabase.open(
        factory: databaseFactoryFfi, path: inMemoryDatabasePath);
    final repos = Repos(db);
    final state = AppState(repos);
    expect(state.isGuest, isFalse);
    expect(state.effectiveRole, '');

    state.enterGuestMode();
    expect(state.isGuest, isTrue);
    expect(state.currentUser, isNull);
    // 'customer' matches no staff destination guard, so the shell
    // only shows Home / Menu / Cart / Orders / Profile.
    expect(state.effectiveRole, 'customer');

    // A guest order places with no cashier — checkout already
    // passes null cashierId/cashierName, so this must not throw.
    final products = await repos.products();
    final burger = products.firstWhere((p) => p.name == 'Zinger Burger');
    final order = await repos.createOrder(OrderDraft(
      customerName: 'Guest Customer',
      customerPhone: '0300 1234567',
      address: 'Pindi Gheb',
      type: 'takeaway',
      paymentMethod: 'Cash',
      items: [CartItem(product: burger, qty: 1)],
    ));
    expect(order.orderNumber, 'PC-000001');
    expect(order.status, 'received');

    // Staff sign-in ends guest mode.
    final admin = await repos.login('admin@pizzaclub.pk', 'Admin123!');
    state.setUser(admin);
    expect(state.isGuest, isFalse);
    expect(state.effectiveRole, 'admin');

    state.enterGuestMode();
    state.exitGuestMode();
    expect(state.isGuest, isFalse);
    await LocalDatabase.close();
  });

  testWidgets('table QR renders (v2.0.1: was blank / hung on Windows)',
      (tester) async {
    // The exact QrImageView the Tables screen now uses: explicit
    // version 4 + white background + error fallback, so a failure
    // shows text instead of a blank dialog.
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Center(
          child: QrImageView(
            data: 'pizzaclub://table/05',
            version: 4,
            errorCorrectionLevel: QrErrorCorrectLevel.M,
            size: 200,
            backgroundColor: Colors.white,
            errorStateBuilder: (ctx, err) =>
                const Text('QR could not be drawn.'),
          ),
        ),
      ),
    ));
    await tester.pump();
    expect(find.byType(QrImageView), findsOneWidget);
    expect(find.text('QR could not be drawn.'), findsNothing);
  });

  test('online URL normalise: https localhost is http, hosted https kept',
      () {
    // v2.0.3: https://localhost:3001 caused "Handshake error …
    // WRONG_VERSION_NUMBER" because the local backend is plain HTTP.
    expect(
      OnlineOrderingService.normaliseBaseUrl('https://localhost:3001'),
      'http://localhost:3001',
    );
    expect(
      OnlineOrderingService.normaliseBaseUrl('https://127.0.0.1:3001/'),
      'http://127.0.0.1:3001',
    );
    expect(
      OnlineOrderingService.normaliseBaseUrl('localhost:3001'),
      'http://localhost:3001',
    );
    expect(
      OnlineOrderingService.normaliseBaseUrl('https://api.example.com'),
      'https://api.example.com',
    );
    expect(
      OnlineOrderingService.friendlyError(
        'HandshakeException: Handshake error in client (OS Error: WRONG_VERSION_NUMBER)',
      ),
      contains('http://localhost:3001'),
    );
  });

  test('password hashing round-trips and rejects wrong passwords', () {
    final hash = PasswordHash.hash('Admin123!');
    expect(PasswordHash.verify('Admin123!', hash), isTrue);
    expect(PasswordHash.verify('wrong', hash), isFalse);
    expect(PasswordHash.verify('Admin123!', 'garbage'), isFalse);
  });

  test('seeded DB has 12 categories and 64 products', () async {
    final db = await LocalDatabase.open(
        factory: databaseFactoryFfi, path: inMemoryDatabasePath);
    final repos = Repos(db);
    final cats = await repos.categories();
    expect(cats.length, 12);
    final products = await repos.products();
    expect(products.length, 64);
    final pizzas = await repos.products(categoryId: 'cat_pizza');
    expect(pizzas.length, 7);
    final tikka = pizzas.firstWhere((p) => p.name.contains('Chicken Tikka'));
    expect(tikka.hasSizes, isTrue);
    final sizes = await repos.sizes(tikka.id);
    expect(sizes.map((s) => s.name).toList(), ['Small', 'Regular', 'Large']);
    expect(sizes[1].pricePaisa, 75000);
    await LocalDatabase.close();
  });

  test('login with default admin, then a full order flow', () async {
    final db = await LocalDatabase.open(
        factory: databaseFactoryFfi, path: inMemoryDatabasePath);
    final repos = Repos(db);

    final admin = await repos.login('admin@pizzaclub.pk', 'Admin123!');
    expect(admin, isNotNull);
    expect(admin!.role, 'admin');
    expect(await repos.login('admin@pizzaclub.pk', 'nope'), isNull);

    final products = await repos.products();
    final burger = products.firstWhere((p) => p.name == 'Zinger Burger');
    final order = await repos.createOrder(OrderDraft(
      customerName: 'Test Customer',
      customerPhone: '0316 4382148',
      address: 'Pindi Gheb',
      type: 'delivery',
      paymentMethod: 'Cash on Delivery',
      cashierId: admin.id,
      cashierName: admin.name,
      items: [CartItem(product: burger, qty: 2)],
    ));
    expect(order.orderNumber, 'PC-000001');
    expect(order.status, 'received');
    expect(order.totalPaisa, 70000);
    final items = await repos.orderItems(order.id);
    expect(items.length, 1);
    expect(items.first.qty, 2);

    // Customer was created from the phone number.
    final customer = await repos.findCustomerByPhone('0316 4382148');
    expect(customer, isNotNull);
    final stats = await repos.customerStats(customer!.id);
    expect(stats['orders'], 1);
    expect(stats['spentPaisa'], 70000);

    // Status flow + completion marks the order paid.
    await repos.updateOrderStatus(order.id, 'accepted');
    await repos.updateOrderStatus(order.id, 'preparing');
    await repos.updateOrderStatus(order.id, 'ready');
    await repos.updateOrderStatus(order.id, 'completed');
    final done = await repos.orderById(order.id);
    expect(done!.status, 'completed');
    expect(done.paymentStatus, 'paid');

    // Reports see the completed sale.
    final today = DateTime.now();
    final summary = await repos.salesSummary(today, today);
    expect(summary.orderCount, 1);
    expect(summary.totalPaisa, 70000);
    final best = await repos.bestSellers(today, today);
    expect(best.first.name, 'Zinger Burger');
    expect(best.first.qty, 2);

    // Empty order and missing name are rejected, never half-saved.
    expect(
        () => repos.createOrder(const OrderDraft(
            customerName: 'X', customerPhone: '', type: 'takeaway',
            paymentMethod: 'Cash', items: [])),
        throwsStateError);
    await LocalDatabase.close();
  });

  // ---- v2.0.0 ----
  Future<Repos> freshRepos() async {
    final db = await LocalDatabase.open(
        factory: databaseFactoryFfi, path: inMemoryDatabasePath);
    return Repos(db);
  }

  Future<InventoryItem> invByName(Repos repos, String name) async {
    final items = await repos.inventoryItems();
    return items.firstWhere((i) => i.name == name);
  }

  test('v2 tables seeded and table state follows its orders', () async {
    final repos = await freshRepos();
    final tables = await repos.tables();
    expect(tables.length, 8);
    expect(tables.map((t) => t.name).toList(),
        ['Table 01', 'Table 02', 'Table 03', 'Table 04', 'Table 05',
         'Table 06', 'Table 07', 'Table 08']);
    expect(await repos.tableStatus('01'), 'Available');

    final products = await repos.products();
    final burger = products.firstWhere((p) => p.name == 'Zinger Burger');
    final order = await repos.createOrder(OrderDraft(
      customerName: 'Dine In', customerPhone: '0300 1112222',
      type: 'dine-in', paymentMethod: 'Cash',
      source: 'QR TABLE', tableNumber: '01',
      items: [CartItem(product: burger, qty: 1)],
    ));
    expect(order.source, 'QR TABLE');
    expect(order.tableNumber, '01');
    expect(await repos.tableStatus('01'), 'Occupied');

    await repos.updateOrderStatus(order.id, 'accepted');
    await repos.updateOrderStatus(order.id, 'preparing');
    await repos.updateOrderStatus(order.id, 'ready');
    expect(await repos.tableStatus('01'), 'Order Ready');

    await repos.updateOrderStatus(order.id, 'completed');
    expect(await repos.tableStatus('01'), 'Available');

    // Completed but unpaid -> Payment Pending.
    final order2 = await repos.createOrder(OrderDraft(
      customerName: 'Dine In 2', customerPhone: '0300 1112223',
      type: 'dine-in', paymentMethod: 'Cash',
      source: 'CASHIER', tableNumber: '02',
      items: [CartItem(product: burger, qty: 1)],
    ));
    await repos.updateOrderStatus(order2.id, 'completed',
        paymentStatus: 'unpaid');
    expect(await repos.tableStatus('02'), 'Payment Pending');

    // Source filter finds only the QR TABLE order.
    final qr = await repos.orders(source: 'QR TABLE');
    expect(qr.length, 1);
    expect(qr.first.orderNumber, order.orderNumber);
    await LocalDatabase.close();
  });

  test('v2 recipe deduction on order, sale never blocked by stock', () async {
    final repos = await freshRepos();
    final products = await repos.products();
    final tikka = products.firstWhere((p) => p.name == 'Chicken Tikka Pizza');
    final lines = await repos.recipesFor(tikka.id);
    expect(lines.map((l) => l.qty).toList(), [150, 100, 30, 1, 1]);

    await repos.createOrder(OrderDraft(
      customerName: 'Recipe', customerPhone: '0300 2223333',
      type: 'takeaway', paymentMethod: 'Cash',
      items: [CartItem(product: tikka, qty: 1)],
    ));
    expect((await invByName(repos, 'Cheese')).quantity, 30000 - 150);
    expect((await invByName(repos, 'Chicken')).quantity, 50000 - 100);
    expect((await invByName(repos, 'Pizza Sauce')).quantity, 20000 - 30);
    expect((await invByName(repos, 'Dough')).quantity, 100 - 1);
    expect((await invByName(repos, 'Pizza Boxes')).quantity, 200 - 1);

    // Drain Cheese to 10g, then order again: sale still completes,
    // Cheese clamps at 0 instead of blocking or going negative.
    final cheese = await invByName(repos, 'Cheese');
    await repos.adjustInventory(cheese.id, -(cheese.quantity - 10), 'test', null);
    final order = await repos.createOrder(OrderDraft(
      customerName: 'Recipe 2', customerPhone: '0300 2223334',
      type: 'takeaway', paymentMethod: 'Cash',
      items: [CartItem(product: tikka, qty: 1)],
    ));
    expect(order.status, 'received');
    expect((await invByName(repos, 'Cheese')).quantity, 0);
    await LocalDatabase.close();
  });

  test('v2 purchase increases stock and is recorded per supplier', () async {
    final repos = await freshRepos();
    final supplier = Supplier(
      id: 'sup_test', name: 'Test Supplier', phone: '0300 9998888',
      address: 'Pindi Gheb', createdAt: '2026-11-17');
    await repos.upsertSupplier(supplier);
    final suppliers = await repos.suppliers();
    expect(suppliers.any((s) => s.name == 'Test Supplier'), isTrue);

    final cheese = await invByName(repos, 'Cheese');
    await repos.recordSupplierPurchase(
      supplierId: supplier.id, inventoryItemId: cheese.id,
      qty: 5000, costPaisa: 120000, purchaseDate: '2026-11-17',
      notes: 'test purchase', by: 'admin');
    expect((await invByName(repos, 'Cheese')).quantity, 30000 + 5000);
    final list = await repos.purchases(supplierId: supplier.id);
    expect(list.length, 1);
    expect(list.first.qty, 5000);
    expect(list.first.costPaisa, 120000);
    await LocalDatabase.close();
  });

  test('v2 order source recorded and discount reduces the total', () async {
    final repos = await freshRepos();
    final products = await repos.products();
    final burger = products.firstWhere((p) => p.name == 'Zinger Burger');
    final order = await repos.createOrder(OrderDraft(
      customerName: 'Discount', customerPhone: '0300 3334444',
      type: 'takeaway', paymentMethod: 'Cash',
      source: 'CASHIER', discountPaisa: 10000,
      items: [CartItem(product: burger, qty: 2)],
    ));
    expect(order.subtotalPaisa, 70000);
    expect(order.discountPaisa, 10000);
    expect(order.totalPaisa, 60000);
    expect(order.source, 'CASHIER');

    final today = DateTime.now();
    final bySource = await repos.salesBySource(today, today);
    expect(bySource['CASHIER'], 60000);
    await LocalDatabase.close();
  });

  test('v2 delivery lifecycle goes through out-for-delivery', () {
    expect(nextOrderStatus('received', 'delivery'), 'accepted');
    expect(nextOrderStatus('accepted', 'delivery'), 'preparing');
    expect(nextOrderStatus('preparing', 'delivery'), 'ready');
    expect(nextOrderStatus('ready', 'delivery'), 'out_for_delivery');
    expect(nextOrderStatus('out_for_delivery', 'delivery'), 'delivered');
    expect(nextOrderStatus('delivered', 'delivery'), 'completed');
    expect(nextOrderStatus('completed', 'delivery'), isNull);
    expect(nextOrderStatus('ready', 'dine-in'), 'completed');
    expect(nextOrderStatus('ready', 'takeaway'), 'completed');
    expect(nextOrderStatus('received', 'dine-in'), 'accepted');
    expect(nextOrderStatus('cancelled', 'delivery'), isNull);
    expect(orderStatusLabel('out_for_delivery'), 'Out for Delivery');
    expect(orderStatusLabel('delivered'), 'Delivered');
  });

  test('v2 online order import dedups on online_order_id', () async {
    final repos = await freshRepos();
    final online = {
      'id': 'PC-ONLINE-0001',
      'customer_name': 'Online Customer',
      'customer_phone': '0300 4445555',
      'address': 'Pindi Gheb',
      'instructions': '',
      'type': 'delivery',
      'payment_method': 'Cash on Delivery',
      'status': 'received',
      'subtotal_paisa': 70000,
      'discount_paisa': 0,
      'delivery_fee_paisa': 0,
      'total_paisa': 70000,
      'items': [
        {
          'product_id': 'p_zinger_burger',
          'product_name': 'Zinger Burger',
          'size_name': '',
          'addons': [],
          'qty': 2,
          'unit_price_paisa': 35000,
        },
      ],
    };
    final first = await repos.importOnlineOrder(online);
    expect(first.source, 'ONLINE');
    expect(first.onlineOrderId, 'PC-ONLINE-0001');
    expect(first.totalPaisa, 70000);
    // v2.0.4: a new web order must be visible in BOTH places — Kitchen
    // (statuses received/accepted/preparing) AND the Staff Orders
    // "New" tab (status received). It was only showing in Kitchen
    // because the customer Orders screen showed nothing until a phone
    // number was typed.
    expect(first.status, 'received');
    final allOrders = await repos.orders();
    expect(allOrders.any((o) => o.id == first.id), isTrue);
    expect(
      allOrders
          .where((o) => o.status == 'received')
          .any((o) => o.id == first.id),
      isTrue,
    );
    final second = await repos.importOnlineOrder(online);
    expect(second.id, first.id);
    final all = await repos.orders(source: 'ONLINE');
    expect(all.length, 1);

    // An accepted online order keeps its status.
    final accepted = await repos.importOnlineOrder({
      ...online,
      'id': 'PC-ONLINE-0002',
      'status': 'accepted',
    });
    expect(accepted.status, 'accepted');
    await LocalDatabase.close();
  });
}
