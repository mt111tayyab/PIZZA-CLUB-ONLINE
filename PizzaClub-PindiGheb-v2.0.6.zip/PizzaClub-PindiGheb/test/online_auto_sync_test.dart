// Pizza Club online auto-sync tests.
//
// Covers AppState.syncOnlineOrders / startOnlineAutoSync:
//   - empty URL defaults to the local backend and fails quietly
//     when it is down (no throw, no version bump),
//   - unreachable backend fails quietly (no throw, no version bump),
//   - a fake backend order is imported once, bumps onlineOrdersVersion,
//     and is deduped on the next sync,
//   - the overlap guard returns immediately while a sync is in flight,
//   - startOnlineAutoSync runs an immediate sync, is idempotent,
//     and dispose() cancels the timer without throwing.
//
// Uses an in-memory sqflite database via sqflite_common_ffi (Linux
// test host) and a real local HttpServer as the fake backend — no
// live server, no network beyond loopback.
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:pizza_club/app_state.dart';
import 'package:pizza_club/data/local_db.dart';
import 'package:pizza_club/data/repositories.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Future<Repos> _openRepos() async {
  final db = await LocalDatabase.open(
      factory: databaseFactoryFfi, path: inMemoryDatabasePath);
  return Repos(db);
}

Map<String, dynamic> _webOrder(String onlineId, String productId,
        int unitPricePaisa) =>
    {
      // NOTE: each test uses its own online id. LocalDatabase.open is
      // a singleton, so every test in this file shares one in-memory
      // DB — reusing an id would make the later test dedup-skip it.
      'id': onlineId,
      'order_number': 'PC-ONLINE-0001',
      'customer_name': 'Test Customer',
      'customer_phone': '03001234567',
      'address': 'Pindi Gheb',
      'type': 'delivery',
      'payment_method': 'Cash',
      'status': 'received',
      'items': [
        {
          'product_id': productId,
          'product_name': 'Test Product',
          'size_name': '',
          'addons': [],
          'qty': 2,
          'unit_price_paisa': unitPricePaisa,
        },
      ],
    };

/// How many local ONLINE orders carry this backend id.
Future<int> _countOnlineId(Repos repos, String onlineId) async {
  final all = await repos.orders(source: 'ONLINE');
  return all.where((o) => o.onlineOrderId == onlineId).length;
}

/// Serves [ordersJson] on GET /api/orders, 404 elsewhere.
Future<HttpServer> _fakeBackend(List<Map<String, dynamic>> ordersJson,
    {Duration delay = Duration.zero}) async {
  final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
  server.listen((req) async {
    if (delay != Duration.zero) await Future<void>.delayed(delay);
    if (req.uri.path == '/api/orders') {
      req.response.headers.contentType = ContentType.json;
      req.response.write(jsonEncode(ordersJson));
    } else {
      req.response.statusCode = 404;
      req.response.write(jsonEncode({'error': 'No such route'}));
    }
    await req.response.close();
  });
  return server;
}

void main() {
  sqfliteFfiInit();

  test('empty URL defaults to the local backend (no throw, no version bump)',
      () async {
    final repos = await _openRepos();
    final state = AppState(repos);
    // No URL saved: the sync now tries http://localhost:3001 by
    // itself. No backend is running in this test, so the fetch
    // fails — but it must fail quietly (no throw, nothing imported,
    // version untouched). The error itself is a connection failure,
    // not a crash.
    final result = await state.syncOnlineOrders();
    expect(result.imported, 0);
    expect(result.skipped, 0);
    expect(state.onlineOrdersVersion, 0);
  });

  test('unreachable backend fails quietly, no throw, no version bump',
      () async {
    final repos = await _openRepos();
    final state = AppState(repos);
    await repos.setSetting('online_api_url', 'http://127.0.0.1:1');
    final result = await state.syncOnlineOrders();
    expect(result.imported, 0);
    expect(result.error, isNotNull);
    expect(state.onlineOrdersVersion, 0);
    // A second sync also stays quiet — the app keeps working offline.
    final again = await state.syncOnlineOrders();
    expect(again.imported, 0);
    expect(state.onlineOrdersVersion, 0);
  });

  test('fake backend order imports once, bumps version, dedups on resync',
      () async {
    final repos = await _openRepos();
    final state = AppState(repos);
    final products = await repos.products();
    expect(products, isNotEmpty);
    final p = products.first;

    final server =
        await _fakeBackend([_webOrder('test-online-1', p.id, p.pricePaisa)]);
    try {
      await repos.setSetting(
          'online_api_url', 'http://127.0.0.1:${server.port}');

      final first = await state.syncOnlineOrders();
      expect(first.error, isNull, reason: first.error);
      expect(first.imported, 1);
      expect(first.skipped, 0);
      expect(state.onlineOrdersVersion, 1);

      final local = await repos.orders(source: 'ONLINE');
      final imported =
          local.where((o) => o.onlineOrderId == 'test-online-1').toList();
      expect(imported, hasLength(1));
      // The local order number is generated locally (PC-000001…);
      // the backend's number is not preserved — the dedup key is
      // the backend id, stored as onlineOrderId.
      expect(imported.first.status, 'received');

      // Second sync: same order is skipped, version does not move.
      final second = await state.syncOnlineOrders();
      expect(second.error, isNull, reason: second.error);
      expect(second.imported, 0);
      expect(second.skipped, 1);
      expect(state.onlineOrdersVersion, 1);
      expect(await _countOnlineId(repos, 'test-online-1'), 1);
    } finally {
      await server.close(force: true);
    }
  });

  test('overlap guard: second sync returns immediately while one is in flight',
      () async {
    final repos = await _openRepos();
    final state = AppState(repos);
    final products = await repos.products();
    final p = products.first;

    // The fake backend answers slowly (800ms) so the first sync is
    // provably still in flight when the second call is made.
    final server = await _fakeBackend(
        [_webOrder('test-online-guard', p.id, p.pricePaisa)],
        delay: const Duration(milliseconds: 800));
    try {
      await repos.setSetting(
          'online_api_url', 'http://127.0.0.1:${server.port}');

      final first = state.syncOnlineOrders();
      // Give the first sync time to start its HTTP request.
      await Future<void>.delayed(const Duration(milliseconds: 200));
      final sw = Stopwatch()..start();
      final second = await state.syncOnlineOrders();
      sw.stop();
      expect(second.imported, 0);
      expect(second.error, isNull);
      // Returned without waiting for the first sync (~800ms) to finish.
      expect(sw.elapsedMilliseconds, lessThan(400));

      final done = await first;
      expect(done.imported, 1);
      expect(state.onlineOrdersVersion, 1);
    } finally {
      await server.close(force: true);
    }
  });

  test(
      'startOnlineAutoSync runs an immediate sync, is idempotent, dispose cancels the timer',
      () async {
    final repos = await _openRepos();
    final state = AppState(repos);
    final products = await repos.products();
    final p = products.first;

    final server =
        await _fakeBackend([_webOrder('test-online-auto', p.id, p.pricePaisa)]);
    try {
      await repos.setSetting(
          'online_api_url', 'http://127.0.0.1:${server.port}');

      state.startOnlineAutoSync();
      // The immediate sync should import within a few seconds.
      final deadline =
          DateTime.now().add(const Duration(seconds: 5));
      while (state.onlineOrdersVersion == 0 &&
          DateTime.now().isBefore(deadline)) {
        await Future<void>.delayed(const Duration(milliseconds: 100));
      }
      expect(state.onlineOrdersVersion, 1);
      expect(await _countOnlineId(repos, 'test-online-auto'), 1);

      // Calling start again must not throw and must not add a
      // second timer (a second immediate sync would import 0 —
      // the order is already there).
      state.startOnlineAutoSync();
      await Future<void>.delayed(const Duration(milliseconds: 300));
      expect(state.onlineOrdersVersion, 1);

      // Dispose cancels the timer without throwing; the state is
      // unusable afterwards, which is the point of disposing it.
      state.dispose();
    } finally {
      await server.close(force: true);
    }
  });
}
