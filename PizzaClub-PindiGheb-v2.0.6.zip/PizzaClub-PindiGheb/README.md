# Pizza Club Pindi Gheb — Ordering + POS (v2.0.5)

## What's new in v2.0.5 (tracking not updating + Delivery/Completed overlap)
- **Tracking fix (root cause):** the app changed an order's status only in its own local database and never told the backend — so the website's "Track your order" page stayed on "Order received" even after the kitchen accepted it. Now every status change (Kitchen, Staff Orders, table close) also PATCHes the backend (`PATCH /api/orders/:id/status`), fire-and-forget — if the backend is down the local change still happens. The track page also re-checks the order quietly every 30 seconds, so a customer watching the page sees the status move without re-typing the number.
- **Delivery/Completed overlap (also fixed here):** completed delivery orders showed in both tabs because the Delivery tab only excluded rejected/cancelled. It now excludes completed too — a completed delivery order lives only under Completed.

## What's new in v2.0.4 (orders only visible in Kitchen)
- **Root cause:** the bottom-nav "Orders" screen is a phone lookup — it showed NOTHING until a phone number was typed. So a web order that was already in Kitchen looked missing there. (The Staff Orders board's "New" tab always showed `received` orders; the order was never lost.)
- **Fix:** staff (Admin/Manager/Cashier) opening "Orders" now see **all recent orders at once**, with a "Staff Orders" button to the full board. A customer who just ordered sees their own orders automatically, using the phone from checkout — no typing needed.

## What's new in v2.0.3 (fetch-order handshake fix)
- **"Handshake error … WRONG_VERSION_NUMBER" when tapping Fetch Online Orders:** the URL box had `https://localhost:3001`, but the local backend is plain HTTP — a TLS handshake sent to a plain-HTTP server fails with exactly that error. The app now corrects it automatically: `https://localhost` / `https://127.0.0.1` are downgraded to `http://` on save and on fetch, a missing scheme gets `http://`, and a real hosted `https://` URL is left alone. The field now also says "Local backend is http, not https — use http://localhost:3001", and if the error ever appears again it says so in plain words instead of the BoringSSL text.

## What's new in v2.0.1 (fixes for the report from the restaurant)
- **Tables QR fixed:** the QR dialog used `QrVersions.auto` with no background and no error fallback — on Windows it rendered blank and looked hung. Now it uses explicit version 4, a white card, an error fallback that shows the link instead of nothing, and a **Copy link** button.
- **Bottom overflow fixed:** the wide sidebar was a non-scrolling `NavigationRail` with 16 items — on a short window it overflowed by ~231px (yellow/black stripes). It is now a scrollable sidebar. The POS cart panel also overflowed (~41px) because ~600px of form fields sat under the items list; the form + items now scroll together and **Complete Sale stays pinned at the bottom**.
- **Smaller menu / POS cards:** menu images are now a fixed 110px (was full-height, ~320px cards), POS images 96px, with 4–5 columns on wide screens — more items visible at once.
- **Cart polished:** compact rows + a **Continue Shopping** button next to Checkout.

Complete, professional restaurant ordering + POS app for Pizza Club Pindi
Gheb, Punjab, Pakistan. Flutter/Dart, Material 3, plus a separate online
ordering backend + web storefront (see below).

**The restaurant app itself is completely offline-first:** no internet, no
cloud, no Firebase/Supabase/PostgreSQL/API/sync is needed for normal
operation. The local sqflite database is the only source of truth for POS,
kitchen, tables, inventory and reports. Remote online ordering is a separate
layer: when the internet is down, local restaurant operation continues and
online orders simply cannot arrive until connectivity is restored.

## What's new in v2.0.0

- **Tables:** Table 01–Table 08 seeded; visual table board (Available /
  Occupied / Order Ready / Payment Pending, derived from open orders);
  open table, add order from a table, transfer a table's open orders to
  another table, close/pay a table. Dine-in checkout requires a table;
  POS can select a table.
- **QR ordering:** each table has a "Show QR" dialog with a QR code for
  `pizzaclub://table/NN` ("Pizza Club Pindi Gheb — Table NN"), shareable.
  A guest who picks Dine-in + a table places a **QR TABLE** order.
- **Order sources:** every order is labelled CASHIER (POS), QR TABLE
  (guest dine-in with a table), APP (guest self-order without a table) or
  ONLINE (imported from the online backend). Source is shown on order
  cards (Staff Orders, Kitchen, order history) and filterable in Staff
  Orders; Reports has a By Source section.
- **Recipes:** per-product recipe editor in Menu Admin. When an order is
  created, recipe ingredients are deducted from inventory in the same
  transaction (logged as `usage`). If stock would go negative it clamps
  at 0 and the sale still completes — a sale is never blocked on stock.
  Seeded recipe: Chicken Tikka Pizza = Cheese 150g, Chicken 100g,
  Pizza Sauce 30g, Dough 1, Pizza Box 1. Inventory is now tracked in
  smallest units (grams / ml / pcs) so recipe grams deduct correctly;
  existing v1 databases are migrated (kg → g, litre → ml, ×1000).
- **Purchases + Suppliers:** supplier CRUD (name, phone, address) with
  purchase history per supplier; recording a purchase increases stock
  in the same transaction.
- **Discounts:** POS discount (0/5/10/15% or a fixed Rs amount) shown in
  totals, checkout summary, receipt and reports.
- **Delivery management:** lifecycle now received → accepted → preparing
  → ready → out_for_delivery → delivered → completed for delivery
  (dine-in/takeaway go ready → completed). Staff Orders has a Delivery
  view with customer/phone/address/items/total/payment/status and a
  delivery-person assignment (users with role `delivery`); tracking
  shows the delivery steps.
- **Order Again:** customer order history has an ORDER AGAIN button that
  re-adds the order's items (sizes included) to the cart.
- **Online ordering (separate, never blocks offline):** `backend/`
  (Node.js, zero npm dependencies, JSON file store, port 3001) +
  `online-web/` (static HTML/CSS/JS storefront, no build step) +
  Flutter Settings → Online Ordering (API URL + Fetch Online Orders;
  dashboard auto-fetches on open when a URL is set). Imported orders
  enter the local DB as source ONLINE, never imported twice, and appear
  in Staff Orders + Kitchen like any order. If the API is unreachable
  the real error is shown and the restaurant keeps working.

## What was built

- **Customer ordering:** Home (real logo + banner hero, ORDER NOW, popular items,
  categories, deals, FREE DELIVERY, contact footer) → Menu (search + categories)
  → Item detail (large photo, sizes Small/Regular/Large for pizza with different
  prices, add-ons, quantity, special instructions, live total) → Cart → Checkout
  (name, phone, address, Delivery/Takeaway/Dine-in, Cash / Cash on Delivery / Card)
  → Order confirmation (order number, timeline Received → Accepted → Preparing →
  Ready → Out for Delivery → Completed) → Order history (search by phone).
- **Staff orders:** New / Active / Completed tabs, Accept / Reject / Print /
  Start Preparing / advance status / Complete (marks paid).
- **Kitchen view:** large cards, order number/time/items/qty/instructions/type,
  New → Preparing → Ready.
- **POS:** search, category grid, size/add-on picker, customer lookup by phone,
  discount, payment Cash/Card/Other, complete sale, 80mm thermal receipt PDF
  (logo, phones, thank-you) via system print or share/save PDF.
- **Admin:** Dashboard (today's sales, low stock, recent orders, best sellers),
  Menu management (add/edit/delete, prices, photos, sizes, add-ons, availability),
  Customers (history, totals, notes), Inventory (adjust, purchase, low-stock),
  Expenses, Reports (daily sales, best sellers, category sales, order status,
  expenses, CSV export), Deals, Settings (restaurant info, delivery fee, tax,
  users/roles, backup/restore, change password).
- **Backup/restore:** export the whole local DB file or a JSON dump, restore from
  a backup file (validated before replacing the live DB). Sales CSV export.
- **Local auth, hashed passwords:** Admin / Manager / Cashier / Kitchen /
  Delivery. Kitchen users see the kitchen only.

## Platforms

Windows, macOS, Android, iOS (Flutter). Web build also compiles, but the app is
designed for installed desktop/mobile use; on web the local DB is in-memory
per session in this build — use Windows/Android for real restaurant use.

## How offline works

sqflite on mobile + `sqflite_common_ffi` on Windows/macOS/Linux (initialised in
`lib/main.dart`). Every sale/order is one DB transaction (order + items + stock
deduction + customer + audit log) with rollback on failure. Money is integer
paisa everywhere. Data survives app close, restart and power failure. No
heartbeat, no sync queue, no online login.

## Default logins (change after first login, in Settings)

| Role | Email | Password |
|---|---|---|
| Admin | admin@pizzaclub.pk | Admin123! |
| Cashier | cashier@pizzaclub.pk | Cashier123! |
| Kitchen | kitchen@pizzaclub.pk | Kitchen123! |

## Prices — PLACEHOLDER, check before selling

No real menu prices were provided. The seed menu uses sensible Pindi Gheb
fast-food placeholder prices, e.g. pizza Small ~Rs 450, Regular ~Rs 750,
Large ~Rs 1,100; burgers Rs 250–550; shawarma Rs 200–350; drinks Rs 80–250.
**These are NOT the restaurant's real prices.** Change every price in
Admin → Menu before selling. Prices are stored in the local DB, not hard-coded.

## Food photos

Every menu item maps to a real local photo under `assets/food/` (see
`ASSET_MAP.md`). Where a category has fewer distinct photos than items, close
items share one photo (e.g. all shawarma items share the shawarma photo).
Photos were found via image search from recipe/restaurant pages; royalty-free
status per photo could not be independently verified — swap in the restaurant's
own dish photos before commercial use if you prefer.

## Branding (real, supplied)

- `assets/branding/pizza_club_logo.png` — Pizza Club, EST. 2024, PINDI GHEB
- `assets/branding/pizza_club_banner.png` — ORDER NOW hero (1600px optimised)
- `assets/branding/original/pizza_club_banner_original.png` — original 3091px banner
- Phones: 0316 4382148 / 0304 8694489 — FREE DELIVERY — EST. 2024 — New Branch

## How to run / build

```bash
cd pizza-club-pindi-gheb
~/flutter/bin/flutter pub get
~/flutter/bin/flutter run -d windows   # Windows desktop
~/flutter/bin/flutter run              # Android device / emulator
~/flutter/bin/flutter run -d macos     # macOS
~/flutter/bin/flutter build web --release
```

### Online ordering (optional, separate)

```bash
node backend/server.js          # backend on http://localhost:3001 (PORT env override)
# serve the storefront from its folder, e.g.:
cd online-web && python3 -m http.server 8000   # http://localhost:8000
```

Then in the Flutter app (Admin): Settings → Online Ordering → enter the
API base URL (e.g. `http://localhost:3001` on the same machine, or your
hosted backend URL) → Fetch Online Orders. The dashboard auto-fetches
when it opens if a URL is set. Change the storefront's API URL in
`online-web/config.js` (one clearly-marked line). The backend stores
orders in `backend/data/orders.json` and its menu in
`backend/data/menu.json` (same 12 categories / 64 products as the app).

Release APK (on a machine with Android SDK 34+ and JDK 17+):

```bash
~/flutter/bin/flutter build apk --release
```

## Backup / restore

Settings → Backup: **Export DB file** (whole `pizza_club.db`), **Export JSON**,
**Restore DB** (pick a `.db` backup; it is validated before replacing the live
DB, then restart the app). Back up regularly — the local DB is the only copy.

## Project layout

```
lib/
  main.dart            entry (sqflite FFI on desktop)
  app_shell.dart       mobile bottom nav / wide sidebar, role gating
  app_state.dart       current user + cart (single source)
  core/                theme (yellow/black/red), money (paisa), ids, PBKDF2 hashing
  data/                local_db.dart (schema+seed), models.dart, repositories.dart,
                       receipt_service.dart (80mm PDF), backup_service.dart
  features/auth/       splash, login
  features/customer/   home, menu, detail, cart, checkout, confirmation, orders, profile
  features/pos/        POS
  features/kitchen/    kitchen view
  features/orders/     staff orders
  features/admin/      dashboard, menu (+recipe editor), customers, inventory, expenses,
                       reports (+by source), deals, settings (+online ordering),
                       tables, suppliers, purchases
  data/online_service.dart  fetch + import online orders (package:http, never blocks offline)
  widgets/             shared components + order detail dialog
assets/branding/       real logo + banner
assets/food/           19 local food photos
backend/               Node stdlib-only online API (server.js, data/menu.json, data/orders.json)
online-web/            static ordering storefront (index.html, app.js, config.js, menu.json)
test/widget_test.dart  money, hashing, seed counts, login + full order flow,
                       guest mode, + 6 v2 tests (tables, recipes, purchases, source/discount,
                       delivery lifecycle, online import dedup)
```

## Honest limits (v2.0.0)

- **QR codes do not install or open the app by themselves.** Scanning a
  table QR on a customer's own phone only opens the ordering flow if the
  Pizza Club app is already installed (deep link `pizzaclub://table/NN`).
  A printed QR alone cannot install the app. In-restaurant QR ordering
  works on the restaurant's own device / a phone with the app installed.
- **Online ordering needs a hosted server.** The backend here is a local
  Node file-store server (no auth, no payments) — it works on the
  restaurant's own machine or any Node host, but it is not a
  production-hardened hosted backend. Until it is hosted somewhere with
  a public URL, remote customers cannot reach it. The restaurant app
  never depends on it.
- No release APK built here (no Android SDK/JDK in this sandbox).
- No Windows/macOS build run here (Linux sandbox); `flutter build web` is
  the compiled check that was run.
- No real thermal printer tested; receipt PDF generation is code-checked
  and covered by the print/share flow, but the first real print must be
  tested on the restaurant's printer.
- No real-device run and no real phone QR scan; the flows are covered by
  the automated tests plus code review of every screen.
- Food photos are stock/search photos, not the restaurant's own dishes.
- Prices are placeholders (see above).

## Verification (v2.0.0 build)

- `flutter pub get` — passed (qr_flutter 4.1.0, http 1.6.0)
- `flutter analyze` — 0 errors, 0 warnings (91 info lints, mostly a
  Flutter 3.50 `material.dart` deprecation info that fires on every file)
- `flutter test` — 11/11 passed (the 5 v1 tests plus 6 new v2 tests:
  tables + table state, recipe deduction + never-blocked sale, purchase
  increases stock, order source + discount total, delivery lifecycle,
  online-order import dedup)
- `flutter build web --release` — succeeded
- Backend: `node backend/server.js` + curl — GET /api/menu (12 categories /
  64 products), POST order (201, PC-ONLINE-0001), invalid order 400,
  GET + PATCH status, persistence in orders.json after restart — all
  verified; see the delivery report for exact results.
